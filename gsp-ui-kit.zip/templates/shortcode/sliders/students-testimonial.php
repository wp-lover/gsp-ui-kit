<div class="swiper gsp-ui-kit-slider mt-4">
    <div class="swiper-wrapper">
        <!-- slider 1 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means. </p>
        </div>
        <!-- slider 2 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means. </p>
        </div>
        <!-- slider 3 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means. </p>
        </div>
        <!-- slider 4 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means. </p>
        </div>
        <!-- slider 5 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means.</p>
        </div>
        <!-- slider 6 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means.</p>
        </div>
        <!-- slider 7 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/Guy_hipster_jumper_man_teacher_sir-512.webp" loading="lazy" alt="" />
            <h3>Profession</h3>
            <h6>Name</h6>
            <p>A purple patch is an over-written passage in which the writer has strained too hard to achieve an impressive effect, by elaborate figures or other means.</p>
        </div>
    </div><!-- .swiper-wrapper -->
    <div class="gsp-ui-kit-slider__pagination"></div>
</div>