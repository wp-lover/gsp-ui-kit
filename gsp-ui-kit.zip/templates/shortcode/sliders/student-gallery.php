<div class="-container swiper gsp-ui-kit-slider mt-4">
    <div class="swiper-wrapper">
        <!-- slider 1 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px;border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-15-at-7.30.06-PM-2.jpeg" loading="lazy" alt="" />
        </div>

        <!-- slider 2 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px; border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/1000097104.jpg" loading="lazy" alt="" />
        </div>

        <!-- slider 3 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px;border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-15-at-7.29.55-PM.jpeg" loading="lazy" alt="" />
        </div>

        <!-- slider 4 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px;border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-15-at-7.29.57-PM-1.jpeg" loading="lazy" alt="" />
        </div>

        <!-- slider 5 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px;border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-15-at-7.29.57-PM-2.jpeg" loading="lazy" alt="" />
        </div>

        <!-- slider 6 -->
        <div class="swiper-slide" style="width: 350px; height: 300px;border-radius: 30px;border:1px solid #92003f;padding:0px;">
            <img style="width:100%;height:100%;object-fit:cover;border-radius:30px;margin:0px;" src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-15-at-7.30.05-PM.jpeg" loading="lazy" alt="" />
        </div>

    </div><!-- .swiper-wrapper -->
    <div class="gsp-ui-kit-slider__pagination"></div>
</div>