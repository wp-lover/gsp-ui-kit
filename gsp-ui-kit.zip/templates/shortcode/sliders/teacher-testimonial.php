<div class="-container swiper gsp-ui-kit-slider mt-4">
    <div class="swiper-wrapper">
        <!-- slider 1 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/02/1740561567082.jpg" loading="lazy" alt="" />
            <h3>ফিজিক্স মেন্টর</h3>
            <h6>ইঞ্জিঃ রিপন ইসলাম (BUTEX)</h6>
            <p>প্রতিষ্ঠাতা ও পরিচালকঃ প্রক্সিমা একাডেমিক এন্ড এডমিশন কেয়ার</p>
            <p>অবিজ্ঞতাঃ ১২ বছর</p>
        </div>
        <!-- slider 2 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-16-at-12.44.57-PM.jpeg" loading="lazy" alt="" />
            <h3>রসায়ন মেন্টর</h3>
            <h6>আদনান স্যার (BUTEX)</h6>
            <p>সিনিয়র শিক্ষকঃ প্রক্সিমা</p>
            <p>অবিজ্ঞতাঃ ৫ বছর</p>
        </div>
        <!-- slider 3 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-16-at-12.44.57-PM-1.jpeg" loading="lazy" alt="" />
            <h3>ম্যাথ মেন্টর</h3>
            <h6>জোবায়ের স্যার (BUTEX)</h6>
            <p> সিনিয়র শিক্ষকঃ প্রক্সিমা</p>
            <p>অবিজ্ঞতাঃ ৫ বছর</p>
        </div>
        <!-- slider 4 -->
        <div class="swiper-slide">
            <img src="https://proximaedutech.com/wp-content/uploads/2025/03/WhatsApp-Image-2025-03-16-at-12.44.58-PM.jpeg" loading="lazy" alt="" />
            <h3>বায়োলজী মেন্টর</h3>
            <h6>রাকিব স্যার (বঙ্গবন্ধু কৃষি বিশ্ববিদ্যালয়)</h6>
            <p> সিনিয়র শিক্ষকঃ প্রক্সিমা</p>
            <p>অবিজ্ঞতাঃ ১০ বছর</p>
        </div>
    </div><!-- .swiper-wrapper -->
    <div class="gsp-ui-kit-slider__pagination"></div>
</div>