<?php 



// silence is golden