<?php

namespace GSP_UI_Kit\Helpers;


// never used
class Template_Include_Filter_Hook {

    public function run( $template ) {
        
    }
}